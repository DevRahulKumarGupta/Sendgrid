"use strict";(()=>{var e={};e.id=453,e.ids=[453],e.modules={2139:e=>{e.exports=require("@sendgrid/mail")},145:e=>{e.exports=require("next/dist/compiled/next-server/pages-api.runtime.prod.js")},6249:(e,t)=>{Object.defineProperty(t,"l",{enumerable:!0,get:function(){return function e(t,o){return o in t?t[o]:"then"in t&&"function"==typeof t.then?t.then(t=>e(t,o)):"function"==typeof t&&"default"===o?t:void 0}}})},4855:(e,t,o)=>{o.r(t),o.d(t,{config:()=>p,default:()=>u,routeModule:()=>h});var r={};o.r(r),o.d(r,{default:()=>c});var n=o(1802),i=o(7153),a=o(6249);require("nodemailer");let d=e=>`<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Order Complete - test</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background-color: #f0f0f0;
                margin: 0;
                padding: 0;
            }
            .header {
                background-color: #4CAF50;
                color: white;
                padding: 20px;
                text-align: center;
            }
            .logo {
                max-width: 150px;
                height: auto;
                margin-bottom: 10px;
            }
            .content {
                background-color: white;
                padding: 30px;
                margin: 20px auto;
                max-width: 600px;
                border-radius: 10px;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            }
            .content h2 {
                color: #333;
            }
            .content p {
                color: #555;
                line-height: 1.6;
            }
            .order-details {
                background-color: #f8f8f8;
                padding: 15px;
                border-radius: 8px;
                margin-top: 20px;
            }
            .order-details li {
                list-style: none;
                padding: 8px 0;
                border-bottom: 1px solid #ddd;
            }
            .order-details li:last-child {
                border-bottom: none;
            }
            .button {
                display: inline-block;
                background-color: #4CAF50;
                color: white;
                padding: 10px 20px;
                text-decoration: none;
                border-radius: 5px;
                margin-top: 20px;
            }
            .footer {
                background-color: #333;
                color: white;
                padding: 10px;
                text-align: center;
                font-size: 12px;
            }
            .white{
                color: white
            }
        </style>
    </head>
    <body>
        <div class="header">
            test
            <h1>Thank You for Your Order!</h1>
        </div>
        <div class="content">
            <h2>Congratulations, ${e}!</h2>
            <p>Your order has been successfully placed. We are thrilled to have you as a customer and are working hard to ensure your order reaches you soon.</p>
            <div class="order-details">
                <h3>Your Order Details:</h3>
               links
            </div>
            <p>You can track your order status and view more details by clicking the button below:</p>
        </div>
        <div class="footer">
            <p>Thank you for shopping with test. We hope to see you again soon!</p>
            <p class="white">test | test | test</p>
        </div>
    </body>
    </html>`,l=o(2139);async function s(e,t,o){l.setApiKey(process.env.SENDGRID_API_KEY||o),console.log(l);let r={to:t,from:"support@mrvideoonline.com",subject:"Test Email",html:d(e)};try{return await l.send(r)}catch(e){return e}}async function c(e,t){let{body:o,method:r}=e,{name:n,email:i}=o;if("POST"===r)try{let e=await s(n,i,process.env.SENDGRID_API_KEY);console.log(e),t.status(200).json(e)}catch(e){console.error(e),t.status(500).send({success:!1,message:"Failed to send email"})}return t.setHeader("Allow",["POST"]),t.status(405).end(`Method ${r} Not Allowed`)}let u=(0,a.l)(r,"default"),p=(0,a.l)(r,"config"),h=new n.PagesAPIRouteModule({definition:{kind:i.x.PAGES_API,page:"/api/hello",pathname:"/api/hello",bundlePath:"",filename:""},userland:r})},7153:(e,t)=>{var o;Object.defineProperty(t,"x",{enumerable:!0,get:function(){return o}}),function(e){e.PAGES="PAGES",e.PAGES_API="PAGES_API",e.APP_PAGE="APP_PAGE",e.APP_ROUTE="APP_ROUTE"}(o||(o={}))},1802:(e,t,o)=>{e.exports=o(145)}};var t=require("../../webpack-api-runtime.js");t.C(e);var o=t(t.s=4855);module.exports=o})();