import templateEmail from "./email";


export{templateEmail}